package com.example.fishfirm1;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}